Udacity Data Wrangling Project WeRateDogs

Project Details:
Tasks in this project are as follows:

I. Data wrangling, which consists of:
1. Gathering data (downloadable file)
2. Assessing data
3. Cleaning data
II. Storing, analyzing, and visualizing wrangled data
III. Reporting on:
1. data wrangling efforts
2. data analyses and visualizations